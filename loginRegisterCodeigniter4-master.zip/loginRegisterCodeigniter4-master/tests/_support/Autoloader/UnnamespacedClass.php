<?php

class UnnamespacedClass
{
}
