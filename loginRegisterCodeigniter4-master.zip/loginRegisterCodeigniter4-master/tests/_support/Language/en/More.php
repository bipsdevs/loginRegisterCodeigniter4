<?php

return [
   'strongForce' => 'These are not the droids you are looking for',
   'notaMoon'    => "That's no moon... it's a space station",
   'cannotMove'  => 'I have a very bad feeling about this',
];
